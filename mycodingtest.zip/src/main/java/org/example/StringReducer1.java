package org.example;

/**
 * For a given string that only contains alphabet characters a-z, if 3 or more consecutive
 * characters are identical, remove them from the string. Repeat this process until
 * there is no more than 3 identical characters sitting besides each other.
 * 对于只包含字母字符a-z的给定字符串，如果连续3个或更多个字符相同，请将其从字符串中删除。重复此过程，直到不超过3个相同的字符并排出现。
 */
public class StringReducer1 {

    public static String reduceString(String input) {
        if (input == null || input.isEmpty()) {
            return input;
        }

        StringBuilder result = new StringBuilder(input);
        boolean modified = true;

        while (modified) {
            modified = false;
            int i = 0;
            while (i < result.length() - 2) { // 至少需要检查三个字符
                if (result.charAt(i) == result.charAt(i + 1) && result.charAt(i + 1) == result.charAt(i + 2)) {
                    // 发现三个或更多连续相同的字符
                    int j = i + 2;
                    while (j < result.length() && result.charAt(j) == result.charAt(i)) {
                        j++;
                    }
                    result.delete(i, j); // 删除连续的字符
                    modified = true;
                    break; // 跳出内层循环，重新开始检查
                } else {
                    i++; // 没有发现连续相同的字符，继续下一个字符
                }
            }
        }

        return result.toString();
    }



}
