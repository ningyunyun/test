package org.example;

/**
 * Instead of removing the consecutively identical characters, replace them with a
 * single character that comes before it alphabetically.
 * 对于给定的字符串 abcccbad  从左往右看第一次 ccc 重复了 .由于c前面的是b,所以用b来代替三个或者更多的连续的c,整个字符串剩余部分变成了abbbad,对吧,那么针对剩下的这个abbbad,从左到右继续看bbb再一次重复了,于是再一次进行替换成了aaad, 再次对aaad进行处理 把aaa去掉 于是最后就剩下了d
 *
 * Example:
 * ccc -> b
 * bbb -> a
 * Input: abcccbad
 * Output:
 * -> abbbad, ccc is replaced by b
 * -> aaad, bbb is replaced by a
 * -> d
 */
public class StringReducer2 {
    public static String reduceString(String input) {
        if (input == null || input.isEmpty()) {
            return input;
        }

        StringBuilder result = new StringBuilder(input);

        boolean modified = true;
        while (modified) {
            modified = false;
            for (int i = 0; i < result.length() - 2; i++) { // 至少需要检查三个字符
                if (result.charAt(i) == result.charAt(i + 1) && result.charAt(i) == result.charAt(i + 2)) {
                    // 发现三个或更多连续相同的字符
                    int j = i + 2;
                    while (j < result.length() && result.charAt(j) == result.charAt(i)) {
                        j++;
                    }
                    if (i > 0) {
                        char replacementChar = result.charAt(i - 1); // 保存前一个字符
                        result.delete(i, j); // 删除连续的字符
                        // 将前一个字符复制到删除的位置
                        for (int k = 0; k < j - i; k++) {
                            result.insert(i + k, replacementChar);
                        }
                    } else {
                        result.delete(i, j); // 删除连续的字符
                    }
                    modified = true;
                    break; // 跳出内层循环，重新开始检查
                }
            }
        }
        return result.toString();
    }
}
