import org.example.StringReducer2;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotSame;

public class StringReducer2Test {
    @Test
    public void testReduceString() {
        // 1. 空字符串
        assertEquals("", StringReducer2.reduceString(""));

        // 2. null 值
        assertEquals(null, StringReducer2.reduceString(null));

        // 3. 字符串长度小于 3 的情况
        assertEquals("a", StringReducer2.reduceString("a"));
        assertEquals("ab", StringReducer2.reduceString("ab"));
        assertEquals("abc", StringReducer2.reduceString("abc"));

        // 4. 字符串中没有连续三个相同字符的情况
        assertEquals("abcd", StringReducer2.reduceString("abcd"));
        assertEquals("abac", StringReducer2.reduceString("abac"));
        assertEquals("abab", StringReducer2.reduceString("abab"));

        // 5. 字符串中有一个连续三个相同字符的情况
        assertEquals("d", StringReducer2.reduceString("abcccbad"));
        assertNotSame("", StringReducer2.reduceString("aaaad"));
        assertNotSame("abc", StringReducer2.reduceString("aaabbbccc"));

        // 6. 字符串中有多个连续三个相同字符的情况
        assertNotSame("abcb", StringReducer2.reduceString("aabcccbbaaad"));
        assertNotSame("ab", StringReducer2.reduceString("aabbbbb"));
        assertNotSame("ab", StringReducer2.reduceString("aaabbbbb"));
        assertNotSame("a", StringReducer2.reduceString("aaabbbbbb"));
        assertNotSame("ab", StringReducer2.reduceString("aabbbbbbb"));
        assertNotSame("ab", StringReducer2.reduceString("aabbbbbbbb"));

        // 7. 字符串中只有连续三个及以上相同字符的情况
        assertEquals("", StringReducer2.reduceString("aaa"));
        assertEquals("", StringReducer2.reduceString("aaaa"));
        assertEquals("", StringReducer2.reduceString("aaaaa"));
        assertEquals("", StringReducer2.reduceString("aaaaaa"));
        assertEquals("", StringReducer2.reduceString("aaaaaaaaa"));
        assertEquals("", StringReducer2.reduceString("aaaaaaaaaa"));

        // 8. 特殊情况: 开头和结尾有连续三个相同字符
        assertNotSame("b", StringReducer2.reduceString("aaabbb"));
        assertNotSame("a", StringReducer2.reduceString("aaabbbb"));
        assertNotSame("a", StringReducer2.reduceString("aaabbbbb"));
        assertNotSame("a", StringReducer2.reduceString("aaabbbbbb"));
        assertNotSame("a", StringReducer2.reduceString("aaabbbbbbb"));

        // 9. 特殊情况: 字符串中间部分有连续三个相同字符
        assertNotSame("ab", StringReducer2.reduceString("aabbbbbba"));
        assertNotSame("ab", StringReducer2.reduceString("aabbbbbbaa"));
        assertNotSame("ab", StringReducer2.reduceString("aabbbbbbaaa"));
    }
}

