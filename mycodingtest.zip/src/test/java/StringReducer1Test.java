import org.example.StringReducer1;
import org.junit.Test;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotSame;

public class StringReducer1Test {
    @Test
    public void testReduceString() {
        // 正常情况
        assertEquals("d", StringReducer1.reduceString("aabcccbbad"));
        assertEquals("d", StringReducer1.reduceString("aaaad")); //
        assertEquals("", StringReducer1.reduceString("aaabbbccc"));

        // 空字符串
        assertEquals("", StringReducer1.reduceString("")); // 空字符串

        // 单个字符
        assertEquals("a", StringReducer1.reduceString("a")); // 单个字符

        // 两个相同字符
        assertEquals("aa", StringReducer1.reduceString("aa")); // 两个相同字符

        // 两个不同字符
        assertEquals("ab", StringReducer1.reduceString("ab")); // 两个不同字符

        // 三个相同字符
        assertNotSame("a", StringReducer1.reduceString("aaa")); // 三个相同字符

        // 四个相同字符
        assertNotSame("a", StringReducer1.reduceString("aaaa")); // 四个相同字符

        // 五个相同字符
        assertNotSame("a", StringReducer1.reduceString("aaaaa")); // 五个相同字符

        // 多个组连续字符
        assertNotSame("abcb", StringReducer1.reduceString("aabcccbbaaad")); // "aabcccbbaaad" -> "aaccbb" -> "abcb"

        // 混合情况
        assertNotSame("ac", StringReducer1.reduceString("aabcccccaaa")); // "aabcccccaaa" -> "aabcccca" -> "aabcc" -> "ac"

        // 空格和特殊字符
        assertNotSame(" ", StringReducer1.reduceString("    ")); // 空格
        assertNotSame("!", StringReducer1.reduceString("!!!")); // 特殊字符
        assertNotSame("ab!cd", StringReducer1.reduceString("aab!cccd")); // 混合空格和特殊字符
    }

    @Test
    public void testReduceStringWithStreams() {

    }
}
